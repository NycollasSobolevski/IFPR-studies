# Placa de carro  > 2023-12-31 7:56pm
https://universe.roboflow.com/trabalho-jnal6/placa-de-carro-oz0eg

Provided by a Roboflow user
License: CC BY 4.0

