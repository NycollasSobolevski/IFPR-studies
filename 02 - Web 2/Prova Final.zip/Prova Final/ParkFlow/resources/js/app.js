import './bootstrap';
import Chart from 'chart.js/auto';

