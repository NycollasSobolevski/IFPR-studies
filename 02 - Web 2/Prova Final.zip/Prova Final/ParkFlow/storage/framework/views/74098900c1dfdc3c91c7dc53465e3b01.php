<?php $__env->startSection('title', 'Users Details - ParkFlow'); ?>

<?php $__env->startSection('header'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/userDetails.css']); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="chart-container">
    <h1>Usuários por cidade</h1>
    <canvas id="myChart"></canvas>
</div>

<script>

    document.addEventListener('DOMContentLoaded', function () {
        const cities = <?php
                echo json_encode($cities);
            ?>
        ;
        const userCounts = <?php
                echo json_encode($userCounts);
            ?>
        ;

        const ctx = document.getElementById('myChart').getContext('2d');
        const usersByCityChart = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: cities,
                datasets: [{
                    label: 'Usuários por cidade',
                    data: userCounts,
                    backgroundColor: 'rgba(54, 162, 235, 0.6)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    });

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nycol\Documents\IFPR-studies\_TCC\WEB\PHP\ParkFlow\resources\views/userDetails.blade.php ENDPATH**/ ?>