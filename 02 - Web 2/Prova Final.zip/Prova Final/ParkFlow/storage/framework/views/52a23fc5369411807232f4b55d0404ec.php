<?php $__env->startSection('title', 'Users - ParkFlow'); ?>

<?php $__env->startSection('header'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/viewUsers.css']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="table-section">

        <div class="table-header">
            <h1>Usuários</h1>

            <form action="/createUser" method="get">
                <button class="primary">
                    <span class="material-symbols-outlined">add</span>
                    <p>Novo</p>
                </button>
            </form>
        </div>

        <table>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Company</th>
            </tr>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->phone); ?></td>
                    <td><?php echo e($user->company->name); ?></td>
                    <td>
                        <form action="/updateUser/<?php echo e($user->id); ?>" method="GET">
                            <button class="secondary" type="submit">
                                <span class="material-symbols-outlined">edit</span>
                                <p>Editar</p>
                            </button>
                        </form>
                    </td>
                    <td>
                        <form action="/deleteUser/<?php echo e($user->id); ?>" method="get">
                            <button class="secondary danger" type="submit">
                                <span class="material-symbols-outlined">delete</span>
                                <p>Excluir</p>
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>


    <?php if($editedUser): ?>
        <div class="edit-user-container">
            <h1>Atualizar Usuário</h1>
            <form action="/updateUser/<?php echo e($editedUser->id); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="input-container">
                    <input type="text" name="username" required value="<?php echo e($editedUser->name); ?>">
                    <label for="username">Name</label>
                </div>
                <div class="input-container">
                    <input type="email" name="email" required value="<?php echo e($editedUser->email); ?>">
                    <label for="email">Email</label>
                </div>
                <div class="input-container">
                    <input type="text" name="phone" required value="<?php echo e($editedUser->phone); ?>">
                    <label for="phone">Phone</label>
                </div>
                <div class="input-container">
                    <select name="company">
                        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option
                            value="<?php echo e($company->id); ?>"
                            <?php if($editedUser->company_id == $company->id): ?>
                                selected
                            <?php endif; ?>
                        >
                            <?php echo e($company->name); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <button type="submit" class="primary">
                    SALVAR
                </button>
            </form>
            <form action="/users" method="get">
                <button type="submit">CANCELAR</button>
            </form>
        </div>
    <?php endif; ?>

    <?php if($newUser): ?>
    <div class="edit-user-container">
            <h1>Adicionar Usuário</h1>
            <form action="/createUser" method="POST">
                <?php echo csrf_field(); ?>
                <div class="input-container">
                    <input type="text" name="username" required>
                    <label for="username">Name</label>
                </div>
                <div class="input-container">
                    <input type="text" name="document" required>
                    <label for="document">Document</label>
                </div>
                <div class="input-container">
                    <input type="password" name="password" required>
                    <label for="password">Password</label>
                </div>
                <div class="input-container">
                    <input type="email" name="email" required>
                    <label for="email">Email</label>
                </div>
                <div class="input-container">
                    <input type="text" name="phone" required>
                    <label for="phone">Phone</label>
                </div>
                <div class="input-container">
                    <select name="company">
                        <option value="" disabled selected>Escolha uma empresa</option>
                        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option
                            value="<?php echo e($company->id); ?>"
                        >
                            <?php echo e($company->name); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <button type="submit" class="primary">
                    SALVAR
                </button>
            </form>
            <form action="/users" method="get">
                <button type="submit">CANCELAR</button>
            </form>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nycol\Documents\IFPR-studies\_TCC\WEB\PHP\ParkFlow\resources\views/viewUsers.blade.php ENDPATH**/ ?>