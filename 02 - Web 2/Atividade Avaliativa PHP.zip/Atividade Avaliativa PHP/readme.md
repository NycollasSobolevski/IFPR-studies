# Atividade Avaliativa WEB II - PHP


Criar uma classe com nome Funcionário conforme definido no diagrama de classe em anexo.
1.Completar os métodos get e set para todos atributos da classe Funcionário.
2.Criar uma página com um formulário para preencher as informações correspondentes a cada atributo.
3.Criar um botão que irá submeter a página realizando as atribuições dos valores lidos a classe e posteriormente a exibição dos mesmos na página do formulário.
4.Criar um método construtor que receba como parâmetro as informações dos atributos da tabela inicializando-os.
5.Adaptar a página para setar os valores da classe pelo método construtor.
Observação: não precisa utilizar Banco de Dados.



Run:
```bash
php -S localhost:3333
```